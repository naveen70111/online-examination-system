# Online Exam System

## Project Description
The Online Exam System is a desktop-based application developed using Java, Swing, JDBC, and MySQL. It is designed to conduct online examinations efficiently by allowing students to take exams and administrators to manage questions and results.

---

## Features
- User Login (Admin and Student)  
- Start Online Exam  
- Subject Selection  
- Multiple Choice Questions  
- Automatic Evaluation of Answers  
- Result Display  
- Question Management (Admin)  

---

## Technologies Used
- Programming Language: Java  
- User Interface: Swing  
- Database: MySQL  
- Connectivity: JDBC  
- IDE: VS Code / Eclipse  

---

## Database
The system uses MySQL database with the following tables:
- Users  
- Subject  
- Question  
- Result  

---

## How to Run the Project

1. Install Java (JDK)  
2. Install MySQL  
3. Create database named `onlineexam`  
4. Run SQL queries to create tables  
5. Update database username and password in the code  
6. Run the main Java file  

---

## Project Structure
- src/ → Java source files  
- db/ → SQL scripts  
- screenshots/ → Project images  
- README.md → Project description  

---

## GitHub Repository
https://github.com/sruthimada1612/Online-Exam-System
---

## Future Enhancements
- Add timer for exams  
- Web-based application  
- Advanced result analysis  
- Improved user interface  

---

## Author
- Sruthi Mada